#include "main.h"

/**
 * mul - multipies two integers
 * @a: number1
 * @b: number2
 * Return: The multiplication result of the numbers
 */

int mul(int a, int b)
{
	return (a * b);
}
