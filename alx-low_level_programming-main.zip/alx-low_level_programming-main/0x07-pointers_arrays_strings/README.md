#07. C - Even more pointers, arrays and strings
## By Alagwu David
## ALX-Software Engineering Programm
``` COHORT 9 ```
