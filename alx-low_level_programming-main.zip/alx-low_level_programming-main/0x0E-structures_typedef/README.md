
0x0E-structures_typedef
