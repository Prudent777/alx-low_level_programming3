# 0x09-Static Libraries
## By Alagwu David
### ALX-Software Engineering Programming
``` COHORT 9 ```
📍 Lagos, Nigeria
