Alx courses are easy and cool
