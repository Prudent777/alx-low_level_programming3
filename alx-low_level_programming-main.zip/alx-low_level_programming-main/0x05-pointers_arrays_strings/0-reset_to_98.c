#include "main.h"

/**
*reset_to_98 - resets the value of given integer to 98
*@n: parameter
*Return : nothing
*/

void reset_to_98(int *n)
{
	*n = 98;
}
