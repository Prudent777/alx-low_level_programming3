# alx-low_level_programming
0x00. C - Hello, World
