My C learning
