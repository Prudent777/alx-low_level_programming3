readme for 0x01-variables
