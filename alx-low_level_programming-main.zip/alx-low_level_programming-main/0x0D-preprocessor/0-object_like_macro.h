#ifndef OBJECT_LIKE_MACRO_H
#define OBJECT_LIKE_MACRO_H

/*
 * JIGJIGA, ETHIOPIA
 * Auth:Ismail Mohamed
 */

#define SIZE 1024

#endif
