# 0x09-static_libraries
## By Alagwu David
### ALX-Software Engineering Programming
``` COHORT 9 ```
Lagos, Nigeria
